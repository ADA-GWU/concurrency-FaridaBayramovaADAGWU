public class Threading extends Thread{

    public static int s;
    public static int x0, y0, x1, y1;
    public static int R[][], G[][], B[][]; //since I need to take pixel size as parameter

    public void run(){
        //math & logic part
        //here I will find Dominant Color or in our case Average color of pixels
        for(int i = x0; i < x1; i += s){
            for(int j = y0; j < y1; j += s){
                int R_av = 0, G_av = 0, B_av = 0;
                int main_size = 0;
                for(int l = 0; l < s; l++) {
                    if (i + l >= x1) continue;
                    for (int k = 0; k < s; k++) {
                        if (j + k >= y1) continue;
                        main_size++;
                        R_av += R[i + l][j + k]; G_av += G[i + l][j + k]; B_av += B[i + l][j + k];
                    }
                }
                if(main_size > 0){
                    R_av /= main_size; G_av /= main_size; B_av /= main_size;
                }
                for(int l = 0; l < s; l++){
                    if(i + l >= x1) continue;
                    for(int k = 0; k < s; k++){
                        if(j + k >= y1) continue;
                        R[i + l][j + k] = R_av; G[i + l][j + k] = G_av; B[i + l][j + k] = B_av;
                    }
                }
            }
        }
    }
}
