//importing libraries
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static JFrame frame = new JFrame(); //creates a JFrame object, but this line does not display the JFrame object anywhere
    public static JLabel label; //this is place to put the icon. This creates a JLabel object and puts the mona lisa.jpg icon on the new label’s face
    public static ImageIcon icon;
    public static int def;
    public static int threads; // this will count threads
    public static char MODE;
    public static String resource = "C:\\\\Users\\\\f.m.bayramova\\\\Desktop\\\\data\\\\uni\\\\spring2021\\\\softdespat\\\\labs\\\\MonaLisa\\\\resources\\\\mona lisa.jpg";
    public static Scanner input; //this is to get input from user
    public static BufferedImage image;
    public static int R[][], G[][], B[][]; //since I need to take pixel size as parameter


    public static void show(BufferedImage image){
        frame.setSize(image.getWidth(), image.getHeight());
        frame.pack();
        icon = new ImageIcon(image);
        label = new JLabel(icon);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        if(args.length !=3) {
            System.out.println("Incorrect:");
        }
        else resource = args[0];
        try {
            def = Integer.parseInt(args[1]);
        }
        catch (NumberFormatException nfe) {
            System.exit(1);
        }
        if(def > 70) System.out.println("Incorrect:");
        MODE = args[2].charAt(0);
        if(MODE == 'S')  threads = 1;
        else if(MODE == 'M') threads = 12;
        else{
            System.out.println("Choose S or M:");
            System.exit(1);
        }
        new Main();
        input = new Scanner(System.in);
        System.out.println("Choose E to exit");
        if(input.nextLine().contains("E")) System.exit(0);
    }

    public Main() {
        try{
            File file = new File("" + resource);
            image = null;
            image = ImageIO.read(file); //reading image
            int width = image.getWidth();
            int height = image.getHeight();
            //array initialization
            R = new int[height][width]; G = new int[height][width]; B = new int[height][width];

            dividing(image);

            //merging - joining threads by Arraylist
            ArrayList<Threading> threads_list = new ArrayList<>();
            for(int i = 0; i < threads; i++){
                Threading threading = new Threading();
                threading.x0 = i * height / threads; threading.x1 = (i + 1) * height / threads;
                threading.y0 = 0; threading.y1 = width;
                threading.R = R; threading.G = G;
                threading.B = B; threading.s = this.def;
                threads_list.add(threading);
                threading.start();
            }
            for(int i = 0; i < threads_list.size(); i++){
                try{
                    threads_list.get(i).join();
                } //exception handling
                catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
            for(int i = 0; i < height; i++){
                for(int j = 0; j < width; j++){
                    image.setRGB(j, i, getRGBArray(R[i][j], G[i][j], B[i][j]));
                }
            }
            show(image);
        } catch (IOException e){
            System.err.println(e.getMessage());
        }
    }
    //encoding RGB
    public static int getRGBArray(int R, int G, int B){
        return ((R << 16) + (G << 8) + B);
    }

    //dividing by smaller pixels
    public static void dividing(BufferedImage image){
        int width = image.getWidth();
        int height = image.getHeight();
        //simple assignment and for loops
        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                int pixel_square = image.getRGB(j, i);
                //the code snippet bellow helps store only yhe last part of the RGB color
                //getting the RGB value all in one integer
                R[i][j] = (pixel_square >>  16) & 0xff;
                G[i][j] = (pixel_square >> 8) & 0xff;
                B[i][j] = (pixel_square) & 0xff;
            }
        }
    }

}
